import React, { Component } from 'react';
import { getDayOfWeek } from '../../../../services/dates.js';
import './style.css';

class Header extends Component {
  render() {
    var weekday = getDayOfWeek(this.props.dt, 'long');
    return (
      <header className="header">
        <h1 className="hdr-1">{`${weekday} Detail`}</h1>
        <h2 className="hdr-2">{`${this.props.city.name}, ${this.props.city.country}`}</h2>
      </header>
    );
  }
}

export default Header;
